import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-produit',
  templateUrl: './home-produit.component.html',
  styleUrls: ['./home-produit.component.css']
})
export class HomeProduitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
